// middleware/auth.js - Authentication and authorization middleware
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const UserRole = require('../models/UserRole');

/**
 * Authentication middleware - verifies JWT token
 */
const auth = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        error: 'No token provided. Access denied.'
      });
    }

    const token = authHeader.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'No token provided. Access denied.'
      });
    }

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      // Find user and check if account is active
      const user = await User.findById(decoded.userId);
      
      if (!user) {
        return res.status(401).json({
          success: false,
          error: 'Invalid token. User not found.'
        });
      }

      if (!user.isActive) {
        return res.status(401).json({
          success: false,
          error: 'Account is deactivated. Please contact support.'
        });
      }

      if (user.isLocked) {
        return res.status(401).json({
          success: false,
          error: 'Account is temporarily locked due to multiple failed login attempts.'
        });
      }

      // Get user role
      const userRoleMapping = await UserRole.findOne({ userId: user._id })
        .populate('roleId', 'roleName');

      const role = userRoleMapping ? userRoleMapping.roleId.roleName : null;

      // Add user info to request object
      req.user = {
        id: user._id,
        username: user.username,
        email: user.email,
        mobile: user.mobile,
        role: role,
        isEmailVerified: user.isEmailVerified,
        isMobileVerified: user.isMobileVerified
      };

      next();

    } catch (tokenError) {
      if (tokenError.name === 'TokenExpiredError') {
        return res.status(401).json({
          success: false,
          error: 'Token expired. Please login again.',
          code: 'TOKEN_EXPIRED'
        });
      }
      
      if (tokenError.name === 'JsonWebTokenError') {
        return res.status(401).json({
          success: false,
          error: 'Invalid token format.',
          code: 'INVALID_TOKEN'
        });
      }

      throw tokenError; // Re-throw if it's not a JWT error
    }

  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({
      success: false,
      error: 'Authentication service error.'
    });
  }
};

/**
 * Role-based authorization middleware
 * @param {string[]} allowedRoles - Array of roles that can access the route
 */
const authorize = (allowedRoles = []) => {
  return (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'Authentication required.'
        });
      }

      if (!req.user.role) {
        return res.status(403).json({
          success: false,
          error: 'User role not found. Access denied.'
        });
      }

      // Check if user's role is in allowed roles
      if (allowedRoles.length > 0 && !allowedRoles.includes(req.user.role)) {
        return res.status(403).json({
          success: false,
          error: `Access denied. Required role: ${allowedRoles.join(' or ')}`
        });
      }

      next();

    } catch (error) {
      console.error('Authorization middleware error:', error);
      res.status(500).json({
        success: false,
        error: 'Authorization service error.'
      });
    }
  };
};

/**
 * Owner-only access middleware
 */
const ownerOnly = (req, res, next) => {
  return authorize(['Mess Owner'])(req, res, next);
};

/**
 * Consumer-only access middleware
 */
const consumerOnly = (req, res, next) => {
  return authorize(['Mess User'])(req, res, next);
};

/**
 * Verified users only middleware
 * Requires mobile verification
 */
const verifiedOnly = (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required.'
      });
    }

    if (!req.user.isMobileVerified) {
      return res.status(403).json({
        success: false,
        error: 'Mobile verification required to access this resource.',
        code: 'MOBILE_VERIFICATION_REQUIRED'
      });
    }

    next();

  } catch (error) {
    console.error('Verification middleware error:', error);
    res.status(500).json({
      success: false,
      error: 'Verification service error.'
    });
  }
};

/**
 * Admin-only access middleware (for future admin features)
 */
const adminOnly = (req, res, next) => {
  return authorize(['Admin'])(req, res, next);
};

/**
 * Rate limiting middleware for authentication endpoints
 */
const authRateLimit = (maxAttempts = 5, windowMs = 15 * 60 * 1000) => {
  const attempts = new Map();

  return (req, res, next) => {
    const ip = req.ip || req.connection.remoteAddress;
    const identifier = req.body.identifier || req.body.mobile || req.body.email;
    const key = `${ip}-${identifier}`;

    const now = Date.now();
    const userAttempts = attempts.get(key) || { count: 0, resetTime: now + windowMs };

    // Reset if time window has passed
    if (now > userAttempts.resetTime) {
      userAttempts.count = 0;
      userAttempts.resetTime = now + windowMs;
    }

    // Check if limit exceeded
    if (userAttempts.count >= maxAttempts) {
      const timeLeft = Math.ceil((userAttempts.resetTime - now) / 1000 / 60);
      return res.status(429).json({
        success: false,
        error: `Too many attempts. Try again in ${timeLeft} minutes.`,
        code: 'RATE_LIMIT_EXCEEDED',
        retryAfter: timeLeft * 60
      });
    }

    // Increment attempts
    userAttempts.count += 1;
    attempts.set(key, userAttempts);

    // Clean up old entries periodically
    if (Math.random() < 0.1) { // 10% chance
      const cutoff = now - windowMs;
      for (const [k, v] of attempts.entries()) {
        if (v.resetTime < cutoff) {
          attempts.delete(k);
        }
      }
    }

    next();
  };
};

/**
 * Optional authentication middleware
 * Doesn't fail if no token provided, but adds user info if valid token exists
 */
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next(); // Continue without authentication
    }

    const token = authHeader.replace('Bearer ', '');
    
    if (!token) {
      return next(); // Continue without authentication
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId);
      
      if (user && user.isActive && !user.isLocked) {
        const userRoleMapping = await UserRole.findOne({ userId: user._id })
          .populate('roleId', 'roleName');

        const role = userRoleMapping ? userRoleMapping.roleId.roleName : null;

        req.user = {
          id: user._id,
          username: user.username,
          email: user.email,
          mobile: user.mobile,
          role: role,
          isEmailVerified: user.isEmailVerified,
          isMobileVerified: user.isMobileVerified
        };
      }
    } catch (tokenError) {
      // Silent fail for optional auth
      console.log('Optional auth failed:', tokenError.message);
    }

    next();

  } catch (error) {
    console.error('Optional auth middleware error:', error);
    next(); // Continue even if there's an error
  }
};

module.exports = {
  auth,
  authorize,
  ownerOnly,
  consumerOnly,
  verifiedOnly,
  adminOnly,
  authRateLimit,
  optionalAuth
};