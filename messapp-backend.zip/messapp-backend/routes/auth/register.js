// routes/auth/register.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../../models/User');
const Role = require('../../models/Role');
const UserRole = require('../../models/UserRole');
const UserProfile = require('../../models/UserProfile');
const { validateMobile, validateEmail, sanitizeString } = require('../../utils/validation');

const router = express.Router();

/**
 * @route   POST /api/auth/register
 * @desc    Register a new user (Consumer or Mess Owner)
 * @access  Public
 */
router.post('/register', async (req, res) => {
  try {
    const {
      username,
      email,
      mobile,
      password,
      role, // 'Mess User' or 'Mess Owner'
      // Consumer specific fields
      fullName,
      address,
      // Owner specific fields
      messName,
      ownerName,
      messAddress,
      licenseNumber,
      gstNumber
    } = req.body;

    // Input validation
    const requiredFields = ['username', 'email', 'mobile', 'password', 'role'];
    for (let field of requiredFields) {
      if (!req.body[field] || req.body[field].toString().trim() === '') {
        return res.status(400).json({
          success: false,
          error: `${field} is required`
        });
      }
    }

    // Validate role
    const validRoles = ['Mess User', 'Mess Owner'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({
        success: false,
        error: 'Role must be either "Mess User" or "Mess Owner"'
      });
    }

    // Role-specific field validation
    if (role === 'Mess User') {
      if (!fullName || !address) {
        return res.status(400).json({
          success: false,
          error: 'Full Name and Address are required for Mess User'
        });
      }
    }

    if (role === 'Mess Owner') {
      if (!messName || !ownerName || !messAddress) {
        return res.status(400).json({
          success: false,
          error: 'Mess Name, Owner Name, and Mess Address are required for Mess Owner'
        });
      }
    }

    // Format and validate mobile number
    let formattedMobile = mobile.toString().trim();
    if (!formattedMobile.startsWith('+')) {
      formattedMobile = formattedMobile.startsWith('91') 
        ? `+${formattedMobile}` 
        : `+91${formattedMobile}`;
    }

    if (!validateMobile(formattedMobile)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid mobile number format. Use +91XXXXXXXXXX'
      });
    }

    // Validate email
    const sanitizedEmail = sanitizeString(email.trim().toLowerCase());
    if (!validateEmail(sanitizedEmail)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email format'
      });
    }

    // Validate password
    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 6 characters long'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [
        { email: sanitizedEmail },
        { mobile: formattedMobile },
        { username: sanitizeString(username.trim()) }
      ]
    });

    if (existingUser) {
      let conflictField = 'user';
      if (existingUser.email === sanitizedEmail) conflictField = 'email';
      else if (existingUser.mobile === formattedMobile) conflictField = 'mobile';
      else if (existingUser.username === sanitizeString(username.trim())) conflictField = 'username';
      
      return res.status(409).json({
        success: false,
        error: `User with this ${conflictField} already exists`
      });
    }

    // Hash password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Create user
    const newUser = new User({
      username: sanitizeString(username.trim()),
      email: sanitizedEmail,
      mobile: formattedMobile,
      password: hashedPassword
    });

    await newUser.save();

    // Find or create role
    let userRole = await Role.findOne({ roleName: role });
    if (!userRole) {
      userRole = new Role({ 
        roleName: role,
        createdBy: newUser._id
      });
      await userRole.save();
    }

    // Create UserRole mapping
    const userRoleMapping = new UserRole({
      userId: newUser._id,
      roleId: userRole._id,
      createdBy: newUser._id
    });
    await userRoleMapping.save();

    // Create user profile based on role
    let profileData = {
      userId: newUser._id,
      createdBy: newUser._id
    };

    if (role === 'Mess User') {
      profileData = {
        ...profileData,
        fullName: sanitizeString(fullName.trim()),
        address: sanitizeString(address.trim())
      };
    } else if (role === 'Mess Owner') {
      profileData = {
        ...profileData,
        messName: sanitizeString(messName.trim()),
        ownerName: sanitizeString(ownerName.trim()),
        messAddress: sanitizeString(messAddress.trim()),
        licenseNumber: licenseNumber ? sanitizeString(licenseNumber.trim()) : null,
        gstNumber: gstNumber ? sanitizeString(gstNumber.trim()) : null,
        isVerified: false // Default to false, admin can verify
      };
    }

    const userProfile = new UserProfile(profileData);
    await userProfile.save();

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: newUser._id,
        role: role 
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Prepare response data (exclude password)
    const responseUser = {
      id: newUser._id,
      username: newUser.username,
      email: newUser.email,
      mobile: newUser.mobile,
      role: role,
      profile: profileData,
      createdAt: newUser.createdAt
    };

    // Log successful registration
    console.log(`✅ New user registered: ${newUser.username} (${role}) - ${formattedMobile}`);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: {
        user: responseUser,
        token,
        expiresIn: '7d'
      }
    });

  } catch (error) {
    console.error('❌ Registration error:', error);
    
    // Handle mongoose validation errors
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: validationErrors
      });
    }

    // Handle duplicate key errors
    if (error.code === 11000) {
      const duplicateField = Object.keys(error.keyPattern)[0];
      return res.status(409).json({
        success: false,
        error: `${duplicateField} already exists`
      });
    }

    res.status(500).json({
      success: false,
      error: 'Internal server error. Please try again later.'
    });
  }
});

module.exports = router;