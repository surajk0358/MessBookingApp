// routes/auth/login.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../../models/User');
const UserRole = require('../../models/UserRole');
const UserProfile = require('../../models/UserProfile');
const { validateEmail, validateMobile, sanitizeString } = require('../../utils/validation');

const router = express.Router();

/**
 * @route   POST /api/auth/login
 * @desc    Login user with username/email/mobile and password
 * @access  Public
 */
router.post('/login', async (req, res) => {
  try {
    const { identifier, password } = req.body;

    // Input validation
    if (!identifier || !password) {
      return res.status(400).json({
        success: false,
        error: 'Username/email/mobile and password are required'
      });
    }

    const sanitizedIdentifier = sanitizeString(identifier.trim());
    
    if (!sanitizedIdentifier || !password.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Invalid credentials provided'
      });
    }

    // Build search query - identifier can be username, email, or mobile
    let searchQuery = {};
    
    // Check if identifier looks like an email
    if (validateEmail(sanitizedIdentifier)) {
      searchQuery.email = sanitizedIdentifier.toLowerCase();
    }
    // Check if identifier looks like a mobile number
    else if (validateMobile(sanitizedIdentifier) || /^\+?91?[6-9]\d{9}$/.test(sanitizedIdentifier)) {
      // Format mobile number consistently
      let formattedMobile = sanitizedIdentifier;
      if (!formattedMobile.startsWith('+')) {
        formattedMobile = formattedMobile.startsWith('91') 
          ? `+${formattedMobile}` 
          : `+91${formattedMobile}`;
      }
      searchQuery.mobile = formattedMobile;
    }
    // Otherwise treat as username, email, or mobile (flexible search)
    else {
      searchQuery = {
        $or: [
          { username: sanitizedIdentifier },
          { email: sanitizedIdentifier.toLowerCase() },
          { mobile: sanitizedIdentifier }
        ]
      };
    }

    // Find user
    const user = await User.findOne(searchQuery);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found. Please check your credentials or register first.'
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    if (!isPasswordValid) {
      // Log failed login attempt
      console.log(`❌ Failed login attempt for: ${sanitizedIdentifier}`);
      
      return res.status(401).json({
        success: false,
        error: 'Invalid password. Please try again.'
      });
    }

    // Get user role
    const userRoleMapping = await UserRole.findOne({ userId: user._id })
      .populate('roleId', 'roleName');

    if (!userRoleMapping || !userRoleMapping.roleId) {
      return res.status(403).json({
        success: false,
        error: 'User role not found. Please contact support.'
      });
    }

    const userRole = userRoleMapping.roleId.roleName;

    // Get user profile
    const userProfile = await UserProfile.findOne({ userId: user._id });

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: user._id,
        role: userRole,
        username: user.username
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Prepare response data (exclude password and sensitive info)
    const responseUser = {
      id: user._id,
      username: user.username,
      email: user.email,
      mobile: user.mobile,
      role: userRole,
      profile: userProfile ? {
        ...userProfile.toObject(),
        userId: undefined, // Remove redundant field
        __v: undefined,
        createdBy: undefined,
        modifiedBy: undefined
      } : null,
      lastLogin: new Date(),
      createdAt: user.createdAt
    };

    // Update last login time
    user.modifiedAt = new Date();
    await user.save();

    // Log successful login
    console.log(`✅ Successful login: ${user.username} (${userRole}) - ${user.mobile}`);

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: responseUser,
        token,
        expiresIn: '7d'
      }
    });

  } catch (error) {
    console.error('❌ Login error:', error);
    
    res.status(500).json({
      success: false,
      error: 'Internal server error. Please try again later.'
    });
  }
});

/**
 * @route   POST /api/auth/otp-login
 * @desc    Login user with OTP (for existing users)
 * @access  Public
 */
router.post('/otp-login', async (req, res) => {
  try {
    const { userId, mobile, otp } = req.body;

    if (!userId || !mobile || !otp) {
      return res.status(400).json({
        success: false,
        error: 'User ID, mobile, and OTP are required'
      });
    }

    // In production, verify OTP with SMS service
    // For demo purposes, accept any 6-digit OTP
    if (!/^\d{6}$/.test(otp)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid OTP format. Must be 6 digits.'
      });
    }

    // Find user
    const user = await User.findById(userId);
    if (!user || user.mobile !== mobile) {
      return res.status(404).json({
        success: false,
        error: 'User not found or mobile number mismatch'
      });
    }

    // Get user role
    const userRoleMapping = await UserRole.findOne({ userId: user._id })
      .populate('roleId', 'roleName');

    if (!userRoleMapping) {
      return res.status(403).json({
        success: false,
        error: 'User role not found'
      });
    }

    const userRole = userRoleMapping.roleId.roleName;

    // Get user profile
    const userProfile = await UserProfile.findOne({ userId: user._id });

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: user._id,
        role: userRole,
        username: user.username
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Prepare response data
    const responseUser = {
      id: user._id,
      username: user.username,
      email: user.email,
      mobile: user.mobile,
      role: userRole,
      profile: userProfile ? {
        ...userProfile.toObject(),
        userId: undefined,
        __v: undefined,
        createdBy: undefined,
        modifiedBy: undefined
      } : null,
      lastLogin: new Date(),
      createdAt: user.createdAt
    };

    // Update last login
    user.modifiedAt = new Date();
    await user.save();

    console.log(`✅ OTP login successful: ${user.username} (${userRole})`);

    res.status(200).json({
      success: true,
      message: 'OTP login successful',
      data: {
        user: responseUser,
        token,
        expiresIn: '7d'
      }
    });

  } catch (error) {
    console.error('❌ OTP login error:', error);
    
    res.status(500).json({
      success: false,
      error: 'Internal server error. Please try again later.'
    });
  }
});

/**
 * @route   GET /api/auth/user/:mobile
 * @desc    Get user by mobile number (for checking if user exists)
 * @access  Public
 */
router.get('/user/:mobile', async (req, res) => {
  try {
    let { mobile } = req.params;
    
    // Format mobile number
    mobile = mobile.replace(/\D/g, ''); // Remove non-digits
    if (!mobile.startsWith('91')) {
      mobile = '91' + mobile;
    }
    if (!mobile.startsWith('+')) {
      mobile = '+' + mobile;
    }

    const user = await User.findOne({ mobile });
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Get user role
    const userRoleMapping = await UserRole.findOne({ userId: user._id })
      .populate('roleId', 'roleName');

    const userRole = userRoleMapping ? userRoleMapping.roleId.roleName : null;

    // Return minimal user info (don't expose sensitive data)
    res.status(200).json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        mobile: user.mobile,
        role: userRole,
        exists: true
      }
    });

  } catch (error) {
    console.error('❌ Get user error:', error);
    
    res.status(500).json({
      success: false,
      error: 'Failed to fetch user information'
    });
  }
});

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user (optional - for token blacklisting if implemented)
 * @access  Private
 */
router.post('/logout', async (req, res) => {
  try {
    // In a full implementation, you might want to:
    // 1. Blacklist the token
    // 2. Clear any refresh tokens
    // 3. Log the logout activity
    
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });

  } catch (error) {
    console.error('❌ Logout error:', error);
    
    res.status(500).json({
      success: false,
      error: 'Logout failed'
    });
  }
});

module.exports = router;