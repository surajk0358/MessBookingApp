// routes/auth.js - Main authentication routes
const express = require('express');
const registerRoutes = require('./auth/register');
const loginRoutes = require('./auth/login');
const { auth } = require('../middleware/auth');
const User = require('../models/User');
const UserProfile = require('../models/UserProfile');

const router = express.Router();

// Import sub-routes
router.use(registerRoutes);
router.use(loginRoutes);

/**
 * @route   GET /api/auth/profile
 * @desc    Get current user profile
 * @access  Private
 */
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    const profile = await UserProfile.findOne({ userId: user._id });

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          mobile: user.mobile,
          isEmailVerified: user.isEmailVerified,
          isMobileVerified: user.isMobileVerified,
          lastLogin: user.lastLogin,
          createdAt: user.createdAt
        },
        profile: profile || null
      }
    });

  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch profile'
    });
  }
});

/**
 * @route   PUT /api/auth/profile
 * @desc    Update user profile
 * @access  Private
 */
router.put('/profile', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const updateData = req.body;

    // Remove fields that shouldn't be updated via this route
    delete updateData.userId;
    delete updateData._id;
    delete updateData.__v;

    let profile = await UserProfile.findOne({ userId });

    if (!profile) {
      // Create new profile if doesn't exist
      profile = new UserProfile({
        userId,
        ...updateData,
        createdBy: userId,
        modifiedBy: userId
      });
    } else {
      // Update existing profile
      Object.assign(profile, updateData);
      profile.modifiedBy = userId;
    }

    await profile.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: { profile }
    });

  } catch (error) {
    console.error('Update profile error:', error);
    
    if (error.name === 'ValidationError') {
      const validationErrors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: validationErrors
      });
    }

    res.status(500).json({
      success: false,
      error: 'Failed to update profile'
    });
  }
});

/**
 * @route   POST /api/auth/change-password
 * @desc    Change user password
 * @access  Private
 */
router.post('/change-password', auth, async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'Current password, new password, and confirmation are required'
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'New password and confirmation do not match'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'New password must be at least 6 characters long'
      });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    if (!isCurrentPasswordValid) {
      return res.status(401).json({
        success: false,
        error: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    user.modifiedBy = req.user.id;
    await user.save();

    console.log(`Password changed for user: ${user.username}`);

    res.status(200).json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to change password'
    });
  }
});

/**
 * @route   POST /api/auth/send-verification-otp
 * @desc    Send OTP for mobile verification
 * @access  Private
 */
router.post('/send-verification-otp', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    if (user.isMobileVerified) {
      return res.status(400).json({
        success: false,
        error: 'Mobile number is already verified'
      });
    }

    // Generate OTP
    const otp = user.generateMobileOTP();
    await user.save();

    // In production, send OTP via SMS service
    console.log(`OTP for ${user.mobile}: ${otp}`);
    
    // For demo purposes, we'll just return success
    res.status(200).json({
      success: true,
      message: 'OTP sent successfully',
      // In production, don't include OTP in response
      debug: process.env.NODE_ENV === 'development' ? { otp } : undefined
    });

  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send OTP'
    });
  }
});

/**
 * @route   POST /api/auth/verify-mobile
 * @desc    Verify mobile number with OTP
 * @access  Private
 */
router.post('/verify-mobile', auth, async (req, res) => {
  try {
    const { otp } = req.body;

    if (!otp) {
      return res.status(400).json({
        success: false,
        error: 'OTP is required'
      });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    if (user.isMobileVerified) {
      return res.status(400).json({
        success: false,
        error: 'Mobile number is already verified'
      });
    }

    // Verify OTP
    if (!user.verifyMobileOTP(otp)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid or expired OTP'
      });
    }

    // Mark mobile as verified
    user.isMobileVerified = true;
    user.clearMobileOTP();
    user.modifiedBy = req.user.id;
    await user.save();

    console.log(`Mobile verified for user: ${user.username}`);

    res.status(200).json({
      success: true,
      message: 'Mobile number verified successfully'
    });

  } catch (error) {
    console.error('Verify mobile error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to verify mobile number'
    });
  }
});

/**
 * @route   GET /api/auth/verify-token
 * @desc    Verify if token is valid and return user info
 * @access  Private
 */
router.get('/verify-token', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          mobile: user.mobile,
          isEmailVerified: user.isEmailVerified,
          isMobileVerified: user.isMobileVerified,
          lastLogin: user.lastLogin
        },
        tokenValid: true
      }
    });

  } catch (error) {
    console.error('Verify token error:', error);
    res.status(500).json({
      success: false,
      error: 'Token verification failed'
    });
  }
});

module.exports = router;