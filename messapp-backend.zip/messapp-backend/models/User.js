// models/User.js - Updated User Model
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    trim: true,
    minlength: [3, 'Username must be at least 3 characters long'],
    maxlength: [30, 'Username cannot exceed 30 characters'],
    validate: {
      validator: function(v) {
        // Username should contain only letters, numbers, underscore, and hyphen
        return /^[a-zA-Z0-9_-]+$/.test(v);
      },
      message: 'Username can only contain letters, numbers, underscore, and hyphen'
    }
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    maxlength: [100, 'Email cannot exceed 100 characters'],
    validate: {
      validator: function(v) {
        return /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(v);
      },
      message: 'Please provide a valid email address'
    }
  },
  mobile: {
    type: String,
    required: [true, 'Mobile number is required'],
    unique: true,
    trim: true,
    validate: {
      validator: function(v) {
        // Supports formats like +919876543210 or +91 9876543210
        return /^\+91[6-9]\d{9}$/.test(v.replace(/\s/g, ''));
      },
      message: 'Please provide a valid Indian mobile number with country code (+91)'
    }
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters long'],
    maxlength: [128, 'Password cannot exceed 128 characters']
  },
  
  // Account status
  isActive: {
    type: Boolean,
    default: true
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  isMobileVerified: {
    type: Boolean,
    default: false
  },
  
  // Security fields
  lastLogin: {
    type: Date,
    default: null
  },
  loginAttempts: {
    type: Number,
    default: 0
  },
  lockUntil: {
    type: Date,
    default: null
  },
  
  // Password reset
  resetPasswordToken: {
    type: String,
    default: null
  },
  resetPasswordExpires: {
    type: Date,
    default: null
  },
  
  // Email verification
  emailVerificationToken: {
    type: String,
    default: null
  },
  emailVerificationExpires: {
    type: Date,
    default: null
  },
  
  // Mobile verification
  mobileOTP: {
    type: String,
    default: null
  },
  mobileOTPExpires: {
    type: Date,
    default: null
  },
  
  // Audit fields
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  modifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  modifiedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for performance
userSchema.index({ email: 1 });
userSchema.index({ mobile: 1 });
userSchema.index({ username: 1 });
userSchema.index({ isActive: 1 });
userSchema.index({ createdAt: -1 });

// Virtual for account lock status
userSchema.virtual('isLocked').get(function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
});

// Pre-save middleware
userSchema.pre('save', function(next) {
  // Update modifiedAt
  this.modifiedAt = new Date();
  
  // Don't hash password if it's already hashed
  if (!this.isModified('password')) return next();
  
  // Validate password strength before hashing (only on new passwords)
  if (this.isNew || this.isModified('password')) {
    const password = this.password;
    
    // Check for minimum requirements
    if (password.length < 6) {
      return next(new Error('Password must be at least 6 characters long'));
    }
    
    // Optional: Add more password strength requirements
    // const hasUpperCase = /[A-Z]/.test(password);
    // const hasLowerCase = /[a-z]/.test(password);
    // const hasNumbers = /\d/.test(password);
    // const hasNonalphas = /\W/.test(password);
    
    // if (!hasUpperCase || !hasLowerCase || !hasNumbers) {
    //   return next(new Error('Password must contain at least one uppercase letter, one lowercase letter, and one number'));
    // }
  }
  
  next();
});

// Pre-save middleware for password hashing
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const saltRounds = 12;
    this.password = await bcrypt.hash(this.password, saltRounds);
    next();
  } catch (error) {
    next(error);
  }
});

// Instance methods
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw new Error('Password comparison failed');
  }
};

userSchema.methods.incrementLoginAttempts = async function() {
  // If we have a previous lock that has expired, restart at 1
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return this.updateOne({
      $unset: { lockUntil: 1 },
      $set: { loginAttempts: 1 }
    });
  }
  
  const updates = { $inc: { loginAttempts: 1 } };
  
  // If we're at max attempts and not locked yet, lock the account
  const maxAttempts = 5;
  const lockTime = 2 * 60 * 60 * 1000; // 2 hours
  
  if (this.loginAttempts + 1 >= maxAttempts && !this.isLocked) {
    updates.$set = { lockUntil: Date.now() + lockTime };
  }
  
  return this.updateOne(updates);
};

userSchema.methods.resetLoginAttempts = async function() {
  return this.updateOne({
    $unset: { loginAttempts: 1, lockUntil: 1 }
  });
};

userSchema.methods.generatePasswordResetToken = function() {
  const crypto = require('crypto');
  const token = crypto.randomBytes(32).toString('hex');
  
  this.resetPasswordToken = token;
  this.resetPasswordExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
  
  return token;
};

userSchema.methods.generateEmailVerificationToken = function() {
  const crypto = require('crypto');
  const token = crypto.randomBytes(32).toString('hex');
  
  this.emailVerificationToken = token;
  this.emailVerificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
  
  return token;
};

userSchema.methods.generateMobileOTP = function() {
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  
  this.mobileOTP = otp;
  this.mobileOTPExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
  
  return otp;
};

userSchema.methods.verifyMobileOTP = function(candidateOTP) {
  if (!this.mobileOTP || !this.mobileOTPExpires) {
    return false;
  }
  
  if (this.mobileOTPExpires < Date.now()) {
    return false; // OTP expired
  }
  
  return this.mobileOTP === candidateOTP;
};

userSchema.methods.clearMobileOTP = function() {
  this.mobileOTP = null;
  this.mobileOTPExpires = null;
};

userSchema.methods.toJSON = function() {
  const user = this.toObject();
  
  // Remove sensitive fields from JSON output
  delete user.password;
  delete user.resetPasswordToken;
  delete user.resetPasswordExpires;
  delete user.emailVerificationToken;
  delete user.emailVerificationExpires;
  delete user.mobileOTP;
  delete user.mobileOTPExpires;
  delete user.loginAttempts;
  delete user.lockUntil;
  delete user.__v;
  
  return user;
};

// Static methods
userSchema.statics.findByIdentifier = function(identifier) {
  const sanitizedIdentifier = identifier.trim();
  
  return this.findOne({
    $or: [
      { username: sanitizedIdentifier },
      { email: sanitizedIdentifier.toLowerCase() },
      { mobile: sanitizedIdentifier }
    ]
  });
};

userSchema.statics.getFailedLogin = async function(identifier) {
  const user = await this.findByIdentifier(identifier);
  
  if (!user || !user.isLocked) {
    return null;
  }
  
  return {
    attemptsLeft: Math.max(0, 5 - user.loginAttempts),
    lockUntil: user.lockUntil
  };
};

module.exports = mongoose.model('User', userSchema);