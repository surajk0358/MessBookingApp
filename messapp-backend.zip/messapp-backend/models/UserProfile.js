// models/UserProfile.js - User Profile Model for additional user information
const mongoose = require('mongoose');

const userProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  
  // Common fields for all users
  profilePicture: {
    type: String, // URL to profile picture
    default: null
  },
  dateOfBirth: {
    type: Date,
    default: null
  },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other', 'Prefer not to say'],
    default: null
  },
  
  // Consumer (Mess User) specific fields
  fullName: {
    type: String,
    maxlength: 100,
    trim: true
  },
  address: {
    type: String,
    maxlength: 500,
    trim: true
  },
  city: {
    type: String,
    maxlength: 50,
    trim: true
  },
  state: {
    type: String,
    maxlength: 50,
    trim: true
  },
  pincode: {
    type: String,
    maxlength: 10,
    trim: true
  },
  coordinates: {
    latitude: {
      type: Number,
      min: -90,
      max: 90
    },
    longitude: {
      type: Number,
      min: -180,
      max: 180
    }
  },
  foodPreferences: {
    type: [String],
    enum: ['veg', 'non-veg', 'vegan', 'jain', 'north-indian', 'south-indian', 'chinese', 'continental'],
    default: []
  },
  allergies: {
    type: [String], // List of food allergies
    default: []
  },
  
  // Owner (Mess Owner) specific fields
  messName: {
    type: String,
    maxlength: 100,
    trim: true
  },
  ownerName: {
    type: String,
    maxlength: 100,
    trim: true
  },
  messAddress: {
    type: String,
    maxlength: 500,
    trim: true
  },
  messCity: {
    type: String,
    maxlength: 50,
    trim: true
  },
  messState: {
    type: String,
    maxlength: 50,
    trim: true
  },
  messPincode: {
    type: String,
    maxlength: 10,
    trim: true
  },
  messCoordinates: {
    latitude: {
      type: Number,
      min: -90,
      max: 90
    },
    longitude: {
      type: Number,
      min: -180,
      max: 180
    }
  },
  licenseNumber: {
    type: String,
    maxlength: 50,
    trim: true,
    default: null
  },
  gstNumber: {
    type: String,
    maxlength: 20,
    trim: true,
    default: null,
    validate: {
      validator: function(v) {
        if (!v) return true; // Allow null/empty
        // Basic GST number validation (15 characters)
        return /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(v);
      },
      message: 'Invalid GST number format'
    }
  },
  panNumber: {
    type: String,
    maxlength: 10,
    trim: true,
    uppercase: true,
    validate: {
      validator: function(v) {
        if (!v) return true; // Allow null/empty
        return /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(v);
      },
      message: 'Invalid PAN number format'
    }
  },
  bankDetails: {
    accountNumber: {
      type: String,
      trim: true
    },
    ifscCode: {
      type: String,
      trim: true,
      uppercase: true
    },
    bankName: {
      type: String,
      trim: true
    },
    accountHolderName: {
      type: String,
      trim: true
    }
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  verificationStatus: {
    type: String,
    enum: ['pending', 'in-review', 'verified', 'rejected'],
    default: 'pending'
  },
  verificationDate: {
    type: Date,
    default: null
  },
  verifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  
  // Common audit fields
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  modifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  modifiedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for performance
userProfileSchema.index({ userId: 1 });
userProfileSchema.index({ messCity: 1, messState: 1 }); // For searching mess owners by location
userProfileSchema.index({ city: 1, state: 1 }); // For searching users by location
userProfileSchema.index({ isVerified: 1, verificationStatus: 1 });

// Virtual for full address (consumer)
userProfileSchema.virtual('fullAddress').get(function() {
  if (!this.address) return null;
  
  const parts = [this.address];
  if (this.city) parts.push(this.city);
  if (this.state) parts.push(this.state);
  if (this.pincode) parts.push(this.pincode);
  
  return parts.join(', ');
});

// Virtual for full mess address (owner)
userProfileSchema.virtual('fullMessAddress').get(function() {
  if (!this.messAddress) return null;
  
  const parts = [this.messAddress];
  if (this.messCity) parts.push(this.messCity);
  if (this.messState) parts.push(this.messState);
  if (this.messPincode) parts.push(this.messPincode);
  
  return parts.join(', ');
});

// Pre-save middleware to update modifiedAt
userProfileSchema.pre('save', function(next) {
  this.modifiedAt = new Date();
  next();
});

// Methods
userProfileSchema.methods.isMessOwner = function() {
  return !!(this.messName && this.ownerName && this.messAddress);
};

userProfileSchema.methods.isMessUser = function() {
  return !!(this.fullName && this.address);
};

userProfileSchema.methods.getLocation = function() {
  if (this.isMessOwner() && this.messCoordinates && this.messCoordinates.latitude && this.messCoordinates.longitude) {
    return {
      latitude: this.messCoordinates.latitude,
      longitude: this.messCoordinates.longitude,
      address: this.fullMessAddress
    };
  } else if (this.coordinates && this.coordinates.latitude && this.coordinates.longitude) {
    return {
      latitude: this.coordinates.latitude,
      longitude: this.coordinates.longitude,
      address: this.fullAddress
    };
  }
  return null;
};

module.exports = mongoose.model('UserProfile', userProfileSchema);